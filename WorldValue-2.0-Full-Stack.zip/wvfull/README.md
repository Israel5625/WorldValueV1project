# WorldValue 2.0 — Full Stack

WorldValue connects people who have problems with people who can solve them. This repository contains the Android app, Supabase database/RLS, payment functions, AI function, GitHub APK build, and the WorldValue icon.

## Included
- Real email/password registration and login through Supabase Auth
- Problems stored online
- User solution submissions
- Project/contribution data model
- Secure customer payment initialization + verification via Paystack Edge Functions
- Contributor transfer endpoint via Paystack
- Contribution ledger
- In-app notifications table
- ValueAI Edge Function
- Admin/dispute data model
- Individual/business/admin account types
- Global-language field and translation-ready UI structure
- WorldValue app icon
- GitHub Actions APK build

## IMPORTANT: activation keys
The Android app deliberately does NOT contain secret payment or AI keys. Before calling this production-ready, create a Supabase project and configure:
- Android: SUPABASE_URL and SUPABASE_ANON_KEY in MainActivity.java (anon key only)
- Supabase Edge secrets: PAYSTACK_SECRET_KEY and OPENAI_API_KEY

For Paystack transfers, the business must have a verified Paystack account and appropriate transfer capability. Never place PAYSTACK_SECRET_KEY or an OpenAI secret key in the Android APK.

## Deploy backend
1. Create a Supabase project.
2. Run `supabase/migrations/001_worldvalue.sql` in the SQL editor.
3. Deploy the four functions under `supabase/functions/`.
4. Set Edge Function secrets.
5. Put only the Supabase URL + anon key in the Android app.
6. Build with GitHub Actions.

## Production checklist
Payment webhooks, refund handling, KYC/identity verification, moderation, rate limiting, audit logs, terms/privacy/consent, tax handling, and a human-reviewed payout workflow should be completed before public launch.
