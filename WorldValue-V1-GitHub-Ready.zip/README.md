# WorldValue V1
Android prototype for the global problem-solving marketplace.

Includes Home, Problems, Post Problem, Submit Solution, Projects, Contribution Ledger, Wallet and Profile.

GitHub Actions builds a debug APK. Real authentication, payments, escrow and backend are intentionally not included in this prototype.
